# Shelter Animals Count Dataset README.txt

## Description

This data describes monthly animal intake and outcome totals as reported to Shelter Animals Count by US-based animal welfare organizations using the Basic Data Matrix. 

### Files

sac_basic_animal_data_with legacy fields.csv -- main data file
definitions.xls -- layout and definitions for the included data
license.txt -- data use policy & agreement
sac_basic_data_matrix_202101.pdf -- additional information on data points and history

### Source

Shelter Animals Count: The National Database 
<http://www.shelteranimalscount.org>

### Date Released
April 8, 2022

### Dates Covered
January 2010 to March 2022

## About this Data

Data is submitted by US-based animal welfare organizations that register with Shelter Animals Count and accept the participant agreement.

Since there is no national requirement for reporting, all data is self-reported and contains natural under and oversampling biases in both the geographic and organization type dimensions. In other words, some areas have a greater level of reporting than others.

### Basic Animal Data Matrix

To facilitate consistent, transparent data collection, the National Federation of Humane Societies developed a "Basic Animal Data Matrix" containing the minimum data points an organization should gather. 

Whether organizations already gather a great deal of data or have only collected the basics, this matrix should facilitate data aggregation at the local, regional or national level by providing a common framework. 

This matrix does not reflect any preference in data analysis or the calculation of rates but is simply a data collection tool.

#### Tracking by Species and Age

The risks associated with being an adult dog, puppy, adult cat, or kitten (or neonate of any kind) in a shelter environment vary a great deal. To help us understand the differing risks for these populations, we collect intake and outcome data by species and age. 

Species: cats, dogs, rabbits, horses, small mammals, farm animals, birds, and reptiles + amphibians. 

Age: adult, youth (up to 5 months), age unknown.

The age tracked within intake categories is the age at intake, and within outcome categories is the age at outcome.

#### Live Admissions Only

We track live admissions only, i.e., animals who are alive when they come into an agency's possession. Animals who are dead when taken into an agency's custody may be a data point to track, but this matrix does not collect that information.

### Methodology

Due to the self-reporting nature of the data, some errors may be present. For instance, city names can be misspelled, and agency names may include acronyms or different DBA names. Some data may be miscoded, particularly under the "other" categories. 

#### 2021 Update

Prior to 2021, the database was limited to cats and dogs and used 14 categories for intakes and outcomes. With the release of the v202101 Basic Data Matrix, the species list expanded to include six additional animal types, transfers were disaggregated to capture distance traveled, and a new category for seized/impounded was added (previously counted under "other intakes").

This file contains the legacy transfer in/out fields along with the new transfer in/out fields by instate, out-of-state, and international status. Legacy fields should only be used if new transfer fields are not complete (NULL or zero).

This file contains the seized/impounded field and should be combined with "other intakes" if looking at years prior to 2021. 

Similarly, because additional species were added in 2021, data entry for those new animal types is underrepresented. 